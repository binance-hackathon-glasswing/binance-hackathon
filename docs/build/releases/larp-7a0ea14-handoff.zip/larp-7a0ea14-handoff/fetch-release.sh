#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
command -v gh >/dev/null || { echo 'Install GitHub CLI and authenticate with mirror repository access.' >&2; exit 2; }
command -v python3 >/dev/null
task_download_dir=$(mktemp -d "${TMPDIR:-/tmp}/larp-7a0ea14.XXXXXX")
trap 'rm -rf -- "$task_download_dir"' EXIT
gh run download 39091699018 --repo Cookiemunchrr/larp-ci-mirror \
  --name larp-bundle-x86_64 --dir "$task_download_dir"
python3 verify-release.py --directory "$task_download_dir"
mkdir -p release
for task_filename in larp-7a0ea1433b3a-x86_64.tar.gz \
  larp-7a0ea1433b3a-x86_64.tar.gz.sha256 \
  larp-7a0ea1433b3a-x86_64.release.json; do
  cp -- "$task_download_dir/$task_filename" "release/$task_filename"
done
python3 verify-release.py --seal
