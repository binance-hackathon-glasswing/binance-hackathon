#!/usr/bin/env python3
"""Verify the exact accepted CI bytes without extracting, installing or executing them."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
BUILD = '7a0ea1433b3a029e9e2dc97817bac98a7e09c0ce'
NAME = 'larp-7a0ea1433b3a-x86_64'
BUNDLE_SHA = 'ff951451bc80b518620f895b2b0a871df188ce2cb2d3e36e04a58754c7f5de06'
MANIFEST_SHA = 'bb17b7ffc28eeb2e14594a80895827bed5327b8408f519692870dcdeffdca70a'
CA_SHA = 'd73890748b5a95551800df8a6f07c9c800e32ed34da7e6c9505918bf8ac2398b'
REPOSITORY = 'https://github.com/binance-hackathon-glasswing/binance-hackathon'


def sha(stream):
    digest = hashlib.sha256()
    for block in iter(lambda: stream.read(1024 * 1024), b''):
        digest.update(block)
    return digest.hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify(directory):
    bundle = directory / (NAME + '.tar.gz')
    manifest_path = directory / (NAME + '.release.json')
    sidecar = directory / (NAME + '.tar.gz.sha256')
    for path in (bundle, manifest_path, sidecar):
        require(path.is_file() and not path.is_symlink(), 'Missing original CI file: ' + path.name)
    with bundle.open('rb') as stream:
        require(sha(stream) == BUNDLE_SHA, 'Bundle differs from the accepted CI bytes')
    raw = manifest_path.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == MANIFEST_SHA, 'Manifest hash differs')
    require(sidecar.read_text().split() == [BUNDLE_SHA, bundle.name], 'CI checksum sidecar differs')
    manifest = json.loads(raw)
    require(manifest['schema'] == 'ReleaseManifest.v1', 'Manifest schema differs')
    require(manifest['build_id'] == BUILD and manifest['repository'] == REPOSITORY,
            'Manifest build/repository identity differs')
    require(manifest['remote_verified'] is True, 'Manifest does not record a pushed build')
    require(type(manifest['files']) is dict and len(manifest['files']) == 192,
            'Expected exactly192 release file hashes')
    with tarfile.open(bundle, 'r:gz') as archive:
        members = archive.getmembers()
        index = {member.name: member for member in members}
        require(len(index) == len(members), 'Duplicate archive members')

        def read_member(name):
            member = index.get(name)
            require(member is not None and member.isfile(), 'Missing regular archive member: ' + name)
            return archive.extractfile(member)

        with read_member(NAME + '/release-manifest.json') as stream:
            require(stream.read() == raw, 'Embedded and external manifests differ')
        with read_member(NAME + '/rds-ca.pem') as stream:
            require(sha(stream) == CA_SHA, 'Included RDS CA differs')
        with read_member(NAME + '/BUNDLE.env') as stream:
            identity = dict(line.split('=', 1) for line in stream.read().decode('utf-8').splitlines())
        require(identity['build_id'] == BUILD and identity['arch'] == 'x86_64', 'Bundle identity differs')
        require(identity['rds_ca_sha256'] == CA_SHA, 'Bundle CA metadata differs')
        for name, expected in manifest['files'].items():
            path = PurePosixPath(name)
            require(not path.is_absolute() and '..' not in path.parts, 'Nonrelative manifest path')
            with read_member(NAME + '/release/' + name) as stream:
                require(sha(stream) == expected, 'Release file hash differs: ' + name)
    return dict(status='ORIGINAL_CI_ARTIFACT_VERIFIED', release_build=BUILD,
                binary_included=True, bundle_sha256=BUNDLE_SHA, manifest_sha256=MANIFEST_SHA,
                verified_manifest_files=192,
                verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, default=ROOT / 'release')
    parser.add_argument('--seal', action='store_true', help='Record success in PACKAGE_STATUS.json')
    args = parser.parse_args()
    try:
        result = verify(args.directory)
        if args.seal:
            require(args.directory.resolve() == (ROOT / 'release').resolve(),
                    'Only the included release directory can seal this handoff')
            (ROOT / 'PACKAGE_STATUS.json').write_text(json.dumps(result, indent=2) + '\n')
    except (OSError, ValueError, KeyError, TypeError, tarfile.TarError) as error:
        print('NOT VERIFIED: ' + str(error), file=sys.stderr)
        return 2
    print(json.dumps(result, indent=2))
    return 0


if __name__ == '__main__':
    sys.exit(main())
