# LARP 7a0ea14 — sendable handoff folder

**The original CI release binary is not included yet.** This is the accepted
release's handoff kit, not a rebuilt deployment bundle. The private CI mirror
returns HTTP404 to this workspace's GitHub account.

Included: accepted bundle/manifest/CA identities, trial decisions and protocol,
the exact two-target gap explanation JSON, and a fetch/verification helper.
No account credentials, wallet keys or host configuration are included.

## Complete this folder with the original release

If you have GitHub CLI access to Cookiemunchrr/larp-ci-mirror, run:

```sh
bash fetch-release.sh
```

It downloads the existing artifact from run39091699018, checks the accepted
bundle and manifest hashes, the embedded manifest, all192 release file hashes,
build/repository identity, architecture and the included CA. It does not build,
install, activate, sign or call any model.

Alternatively, copy these three original CI files into `release/`, then run
`python3 verify-release.py --seal`:

- larp-7a0ea1433b3a-x86_64.tar.gz
- larp-7a0ea1433b3a-x86_64.tar.gz.sha256
- larp-7a0ea1433b3a-x86_64.release.json

Yao's earlier handoff records those originals on Yao's machine under
`deploy/activation/releases/mirror-39091699018/`; that is a location reported by
the owner, not a directory accessible from this cloud workspace.

After verification, PACKAGE_STATUS.json records binary_included=true. Send the
whole folder (or ZIP it). Keep the original tar.gz unchanged; do not substitute
an archive rebuilt from the same Git commit. This folder is an unsigned-shadow
trial handoff. Host report, provider/budget checks, binding, activation and the
first assessment remain the host owner's steps.

Start with [the trial handoff](docs/build/MODEL_TRIAL_HANDOFF_20261018.md).
Repository references not copied into this kit link to their exact published
commit. The historical mirror evidence says PENDING_KEEGAN at its original
verification time; the separate TR-AC2 decision records the later acceptance.
