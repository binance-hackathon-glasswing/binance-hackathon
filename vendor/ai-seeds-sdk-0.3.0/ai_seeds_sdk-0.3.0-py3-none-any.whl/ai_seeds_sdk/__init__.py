"""ai-seeds SDK: record trading-agent decision rounds to the ai-seeds ingest service (protocol 2.0).

    from ai_seeds_sdk import Client
    client = Client(address="0x...")                 # mode="realtime" (default) or "batch"
    client.log(input=prompt, cot=thinking, output=answer,
               orders=[{"symbol": "NVDAB", "side": "BUY", "amount": "0.15", "tx_hash": "0x..."}])
"""

from .client import Client
from .errors import UploadError, ValidationError

__version__ = "0.3.0"
__all__ = ["Client", "UploadError", "ValidationError", "__version__"]
