"""Local validation rules (PROTOCOL.md sections 1 and 5) and JSON conversion of user objects.

The server applies the same rules; validating before sending lets callers see
all problems at once, and guarantees that every line written locally is valid.
"""

from __future__ import annotations

import dataclasses
import datetime
import decimal
import enum
import math
import re
import uuid
from typing import Any, List, Optional

EVENT_ID_PATTERN = re.compile(r"[A-Za-z0-9._:-]{1,128}")
ADDRESS_PATTERN = re.compile(r"0x[0-9a-fA-F]{40}")
TX_HASH_PATTERN = re.compile(r"0x[0-9a-fA-F]{64}")
SIDES = ("BUY", "SELL")

_INT64_MIN, _INT64_MAX = -(2 ** 63), 2 ** 63 - 1
_MAX_DEPTH = 200


def validate_address(address: Any) -> Optional[str]:
    """Return an error message, or None if ``address`` is a well-formed wallet address."""
    if not isinstance(address, str) or not ADDRESS_PATTERN.fullmatch(address):
        return f"address must match ^0x[0-9a-fA-F]{{40}}$, got {address!r}"
    return None


def validate_event_id(event_id: Any) -> Optional[str]:
    if not isinstance(event_id, str) or not EVENT_ID_PATTERN.fullmatch(event_id):
        return f"eventId must match ^[A-Za-z0-9._:-]{{1,128}}$, got {event_id!r}"
    return None


# ------------------------------------------------------------ JSON conversion

class _Unconvertible(Exception):
    def __init__(self, path: str, message: str) -> None:
        super().__init__(message)
        self.path = path
        self.message = message


def to_json_value(value: Any, path: str) -> Any:
    """Convert ``value`` to plain JSON types, or raise ``ValueError`` naming the offending path.

    Model / framework objects are converted with, in order: ``model_dump()``
    (pydantic v2), ``dict()`` (pydantic v1), ``to_dict()``, ``dataclasses.asdict``.
    Common value types are converted the same way in all three SDKs: date / time /
    datetime -> ISO 8601 string, Decimal -> decimal string (no float rounding),
    set / frozenset -> list, UUID -> string, Enum -> its name.
    Anything else that is not JSON (e.g. bytes) is rejected (there is no ``str()`` fallback).
    """
    try:
        return _convert(value, path, 0)
    except _Unconvertible as exc:
        raise ValueError(f"{exc.path}: {exc.message}") from None


def _convert(value: Any, path: str, depth: int) -> Any:
    if depth > _MAX_DEPTH:
        raise _Unconvertible(path, f"nested deeper than {_MAX_DEPTH} levels")
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise _Unconvertible(path, f"{value!r} is not valid JSON")
        return value
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            if isinstance(key, bool) or not isinstance(key, (str, int)):
                raise _Unconvertible(path, f"object keys must be strings, got {type(key).__name__}")
            key = str(key)
            out[key] = _convert(item, f"{path}.{key}", depth + 1)
        return out
    if isinstance(value, (list, tuple)):
        return [_convert(item, f"{path}[{i}]", depth + 1) for i, item in enumerate(value)]
    if isinstance(value, (datetime.date, datetime.time)):  # datetime is a date subclass
        return value.isoformat()
    if isinstance(value, decimal.Decimal):
        if not value.is_finite():
            raise _Unconvertible(path, f"{value!r} is not valid JSON")
        return str(value)
    if isinstance(value, (set, frozenset)):
        return [_convert(item, f"{path}[{i}]", depth + 1) for i, item in enumerate(value)]
    if isinstance(value, uuid.UUID):
        return str(value)
    if isinstance(value, enum.Enum):
        return value.name
    if isinstance(value, (bytes, bytearray, memoryview)):
        raise _Unconvertible(path, f"{type(value).__name__} is binary, not JSON; decode it to a string first")
    converted = _object_to_json(value, path)
    return _convert(converted, path, depth + 1)


def _object_to_json(value: Any, path: str) -> Any:
    kind = type(value).__name__
    try:
        method = getattr(value, "model_dump", None)  # pydantic v2
        if callable(method):
            try:
                return method(mode="json")
            except TypeError:  # model_dump() without a `mode` parameter
                return method()
        method = getattr(value, "dict", None)  # pydantic v1
        if callable(method) and not isinstance(value, type):
            return method()
        method = getattr(value, "to_dict", None)
        if callable(method) and not isinstance(value, type):
            return method()
    except _Unconvertible:
        raise
    except Exception as exc:  # the object's own converter failed
        raise _Unconvertible(path, f"converting {kind} to JSON failed: {exc}") from None
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        return dataclasses.asdict(value)
    raise _Unconvertible(
        path, f"object of type {kind} is not JSON; pass str/dict/list, or an object with "
              "model_dump(), dict(), to_dict(), or a dataclass"
    )


# ------------------------------------------------------------ content rules

def _require_non_empty(value: Any, path: str, errors: List[str]) -> None:
    """"Required / non-empty": present, not null, strings not blank, objects and lists not empty."""
    if value is None:
        errors.append(f"{path} is required")
    elif isinstance(value, str) and not value.strip():
        errors.append(f"{path} must not be blank")
    elif isinstance(value, (dict, list)) and not value:
        errors.append(f"{path} must not be empty")


def validate_event(event: Any) -> List[str]:
    """Validate a converted log ``{"timestamp", "data": {...}}``; return one message per problem."""
    if not isinstance(event, dict):
        return ["event must be a JSON object"]
    errors: List[str] = []
    ts = event.get("timestamp")
    if ts is None:
        errors.append("timestamp is required")
    elif isinstance(ts, bool) or not isinstance(ts, int) or not _INT64_MIN <= ts <= _INT64_MAX:
        errors.append("timestamp must be an integer (epoch ms)")

    data = event.get("data")
    if data is None:
        errors.append("data is required")
        return errors
    if not isinstance(data, dict):
        errors.append("data must be a JSON object")
        return errors
    for key in ("input", "cot", "output"):
        _require_non_empty(data.get(key), f"data.{key}", errors)
    _validate_orders(data.get("orders"), errors)
    return errors


def _validate_orders(orders: Any, errors: List[str]) -> None:
    if orders is None:
        errors.append("data.orders is required (use [] when only holding)")
        return
    if not isinstance(orders, list):
        errors.append("data.orders must be a list")
        return
    for i, order in enumerate(orders):
        path = f"data.orders[{i}]"
        if not isinstance(order, dict):
            errors.append(f"{path} must be a JSON object")
            continue
        symbol = order.get("symbol")
        if not isinstance(symbol, str) or not symbol.strip():
            errors.append(f"{path}.symbol must be a non-blank string")
        if order.get("side") not in SIDES:
            errors.append(f"{path}.side must be BUY or SELL, got {order.get('side')!r}")
        amount = order.get("amount")
        amount_ok = (isinstance(amount, (int, float)) and not isinstance(amount, bool)) or (
            isinstance(amount, str) and amount.strip() != "")
        if not amount_ok:
            errors.append(f"{path}.amount must be a non-blank string or a number")
        tx_hash = order.get("tx_hash")  # optional; null counts as not filled (same as the server)
        if tx_hash is not None and not (isinstance(tx_hash, str) and TX_HASH_PATTERN.fullmatch(tx_hash)):
            errors.append(f"{path}.tx_hash must match ^0x[0-9a-fA-F]{{64}}$, got {tx_hash!r}")
