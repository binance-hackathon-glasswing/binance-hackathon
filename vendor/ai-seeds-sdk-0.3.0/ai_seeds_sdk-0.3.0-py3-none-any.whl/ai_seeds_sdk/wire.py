"""Wire-format helpers: canonical log text, chunking, hashing, JSONL parts, multipart encoding."""

from __future__ import annotations

import hashlib
import hmac
import json
import uuid
from typing import Any, List, Tuple

PROTOCOL_VERSION = "2.0"
MAX_CHUNK_BYTES = 65536
MAX_CHUNK_COUNT = 128

MAX_FILE_BYTES = 10 * 1024 * 1024
MAX_FILE_LINES = 100_000


def canonical_string(method: str, path: str, timestamp: str, nonce: str, address: str,
                     content_sha256: str) -> str:
    """The string signed for one request (PROTOCOL.md section 2): six items joined by LF."""
    return "\n".join([method.upper(), path, timestamp, nonce, address.lower(), content_sha256])


def sign(secret: str, canonical: str) -> str:
    """HMAC-SHA256 of the canonical string, keyed with the UTF-8 bytes of the team secret."""
    return hmac.new(secret.encode("utf-8"), canonical.encode("utf-8"), hashlib.sha256).hexdigest()


def compact_json(value: Any) -> str:
    """Compact JSON (``,`` / ``:`` separators, non-ASCII kept). NaN/Infinity are rejected."""
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def sha256_hex(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def split_chunks(text: str, max_bytes: int = MAX_CHUNK_BYTES) -> List[str]:
    """Split ``text`` into pieces of at most ``max_bytes`` UTF-8 bytes each.

    Cuts only on code-point boundaries, so every piece decodes on its own and
    ``"".join(pieces) == text``.
    """
    if max_bytes < 4:
        raise ValueError("max_bytes must be at least 4 (longest UTF-8 sequence)")
    data = text.encode("utf-8")
    chunks: List[str] = []
    start = 0
    while start < len(data):
        end = min(start + max_bytes, len(data))
        # Step back while `end` points at a continuation byte (10xxxxxx).
        while end < len(data) and (data[end] & 0xC0) == 0x80:
            end -= 1
        chunks.append(data[start:end].decode("utf-8"))
        start = end
    return chunks


def dedupe_lines(content: bytes) -> List[bytes]:
    """Non-blank JSONL lines (without line endings), keeping only the first line per eventId.

    Lines that are not JSON objects with a string ``eventId`` are kept as-is.
    """
    seen = set()
    out: List[bytes] = []
    if content.startswith(b"\xef\xbb\xbf"):
        content = content[3:]
    for line in content.split(b"\n"):
        line = line.rstrip(b"\r")
        if not line.strip():
            continue
        try:
            obj = json.loads(line.decode("utf-8"))
            event_id = obj.get("eventId") if isinstance(obj, dict) else None
        except ValueError:
            event_id = None
        if isinstance(event_id, str):
            if event_id in seen:
                continue
            seen.add(event_id)
        out.append(line)
    return out


def split_parts(lines: List[bytes], max_bytes: int = MAX_FILE_BYTES,
                max_lines: int = MAX_FILE_LINES) -> List[bytes]:
    """Group lines into file bodies of at most ``max_bytes`` bytes and ``max_lines`` lines.

    Each body ends with a newline. A single line larger than ``max_bytes`` gets a
    part of its own (the server will refuse it, but it is never silently dropped).
    """
    parts: List[bytes] = []
    current: List[bytes] = []
    size = 0
    for line in lines:
        cost = len(line) + 1
        if current and (size + cost > max_bytes or len(current) >= max_lines):
            parts.append(b"\n".join(current) + b"\n")
            current, size = [], 0
        current.append(line)
        size += cost
    if current:
        parts.append(b"\n".join(current) + b"\n")
    return parts


def encode_multipart(fields: List[Tuple[str, str]], file_field: str, filename: str,
                     content: bytes, content_type: str) -> Tuple[bytes, str]:
    """Build a multipart/form-data body; returns ``(body, content_type_header)``."""
    boundary = "ai-seeds-" + uuid.uuid4().hex
    crlf = b"\r\n"
    parts: List[bytes] = []
    for name, value in fields:
        parts += [
            b"--" + boundary.encode("ascii"),
            f'Content-Disposition: form-data; name="{name}"'.encode("utf-8"),
            b"",
            value.encode("utf-8"),
        ]
    safe_name = filename.replace("\\", "_").replace('"', "%22").replace("\r", "").replace("\n", "")
    parts += [
        b"--" + boundary.encode("ascii"),
        f'Content-Disposition: form-data; name="{file_field}"; filename="{safe_name}"'.encode("utf-8"),
        f"Content-Type: {content_type}".encode("ascii"),
        b"",
        content,
        b"--" + boundary.encode("ascii") + b"--",
        b"",
    ]
    return crlf.join(parts), f"multipart/form-data; boundary={boundary}"
