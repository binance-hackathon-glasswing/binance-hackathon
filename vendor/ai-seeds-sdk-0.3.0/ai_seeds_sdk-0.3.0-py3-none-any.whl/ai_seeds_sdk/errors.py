"""Exception types raised by the SDK."""

from __future__ import annotations

from typing import Any, Dict, List, Optional


class ValidationError(ValueError):
    """Local validation failed; nothing was sent to the server.

    ``errors`` holds one human-readable message per problem.
    """

    def __init__(self, errors: List[str]) -> None:
        self.errors: List[str] = list(errors)
        super().__init__("; ".join(self.errors) if self.errors else "validation failed")


class UploadError(Exception):
    """The server rejected a log (400 / 401 / other 4xx); it is not retried or saved locally.

    Transient failures (network / 5xx / 429) never reach the caller of ``log()``:
    after the retries the log is saved and re-sent automatically.

    Attributes:
        status: HTTP status code, or ``None`` for network errors.
        code: Error code from the server body (e.g. ``VALIDATION_FAILED``),
            or ``NETWORK_ERROR`` / ``HTTP_<status>`` when the body has none.
        message: Human-readable message.
        line_errors: ``lineErrors`` from a rejected file upload (may be empty).
        retryable: True if the failure was transient (network / 5xx / 429)
            and was raised only because retries were exhausted.
    """

    def __init__(
        self,
        status: Optional[int],
        code: str,
        message: str,
        line_errors: Optional[List[Dict[str, Any]]] = None,
        retryable: bool = False,
    ) -> None:
        self.status = status
        self.code = code
        self.message = message
        self.line_errors: List[Dict[str, Any]] = list(line_errors or [])
        self.retryable = retryable
        prefix = f"HTTP {status}" if status is not None else "network error"
        super().__init__(f"{prefix} {code}: {message}")
