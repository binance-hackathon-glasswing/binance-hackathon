"""Client for the ai-seeds log ingest service (PROTOCOL.md 2.0).

One ``Client`` per process. ``log()`` records one decision round; in ``realtime``
mode it is uploaded immediately (failed uploads go to a local spool that a
background thread re-sends), in ``batch`` mode it is appended to a daily file
that a background thread pushes shortly after the next UTC midnight.
"""

from __future__ import annotations

import datetime as _dt
import glob
import hashlib
import http.client
import json
import logging
import os
import random
import re
import threading
import time
import urllib.error
import urllib.request
import uuid
from typing import Any, Callable, Dict, List, Optional, Tuple

from . import validation, wire
from .errors import UploadError, ValidationError

__all__ = ["Client", "DEFAULT_BASE_URL"]

logger = logging.getLogger("ai_seeds_sdk")

# Official service address, built into the SDK. Env AI_SEEDS_URL or the base_url argument
# overrides it (e.g. for a test environment).
DEFAULT_BASE_URL = "https://api.commonservice.io/ai-seeds-event-log"

VERSION = "0.3.0"  # keep in sync with __version__ (__init__.py imports this module first)
USER_AGENT = f"ai-seeds-sdk-python/{VERSION}"
# Helper script inside the unzipped SDK bundle (ai-seeds-sdk-<version>.zip)
MANUAL_PUSH_SCRIPT = f"ai-seeds-sdk-{VERSION}/examples/manual_push.sh"
MODES = ("realtime", "batch")
FLUSH_INTERVAL = 30.0  # realtime: spool check period (seconds)
BATCH_RETRY_INTERVAL = 30 * 60.0  # batch: retry period for failed parts (seconds)
BATCH_DELAY_RANGE = (120.0, 600.0)  # batch: random delay after UTC midnight (seconds)
FILE_TIMEOUT = 120.0  # internal file upload timeout (seconds)
_WAIT_STEP = 60.0  # re-read the clock at least this often while waiting for a deadline
_DAY = 86400
_MISSING: Any = object()
_PART_PATTERN = re.compile(r"\.part(\d+)\.jsonl$")


class Client:
    """Records agent decision rounds to ai-seeds.

    Args:
        address: Registered wallet address; defaults to env ``AI_SEEDS_ADDRESS``.
        mode: ``"realtime"`` (default, upload on every ``log()``) or ``"batch"``
            (append to a daily file, pushed after the next UTC midnight).
        data_dir: Local directory for the spool / batch files (default ``.ai-seeds``
            under the current directory). Do not share it between processes.
        secret: The team's signing secret issued with the registration (or env
            ``AI_SEEDS_SECRET``). Every request is signed with it; keep it out of logs and code.

    The official service address is built in (``DEFAULT_BASE_URL``); set env ``AI_SEEDS_URL``
    only to use another one, e.g. a test environment.

    Create a single Client per process; it may be shared between threads.
    """

    def __init__(
        self,
        address: Optional[str] = None,
        mode: str = "realtime",
        data_dir: str = ".ai-seeds",
        secret: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        timeout: float = 15.0,
        retries: int = 3,
        backoff: float = 0.5,
        sleep: Callable[[float], Any] = time.sleep,
        flush_interval: float = FLUSH_INTERVAL,
        now: Callable[[], float] = time.time,
        wait: Optional[Callable[[float], Any]] = None,
    ) -> None:
        # base_url, timeout, retries, backoff, sleep, flush_interval, now and wait are
        # internal knobs for tests; participants only pass address / mode / data_dir / secret.
        if secret is None:
            secret = os.environ.get("AI_SEEDS_SECRET", "").strip() or None
        if not isinstance(secret, str) or not secret.strip():
            raise ValueError("secret is required (argument or env AI_SEEDS_SECRET)")
        if address is None:
            address = os.environ.get("AI_SEEDS_ADDRESS", "").strip() or None
        if not address:
            raise ValueError("address is required (argument or env AI_SEEDS_ADDRESS)")
        address_error = validation.validate_address(address)
        if address_error:
            raise ValidationError([address_error])
        url = base_url or os.environ.get("AI_SEEDS_URL", "").strip() or DEFAULT_BASE_URL
        if not url.startswith(("http://", "https://")):
            raise ValueError(f"service URL must start with http:// or https://, got {url!r}")
        if mode not in MODES:
            raise ValueError(f"mode must be 'realtime' or 'batch', got {mode!r}")
        if retries < 0:
            raise ValueError("retries must be >= 0")

        self.address = address
        self.mode = mode
        self._secret = secret  # signs every request; never logged
        self.base_url = url.rstrip("/")
        self.data_dir = os.path.abspath(data_dir)
        self.spool_path = os.path.join(self.data_dir, "spool.jsonl")
        self.batch_dir = os.path.join(self.data_dir, "batch")
        self._timeout = timeout
        self._retries = retries
        self._backoff = backoff
        self._sleep = sleep
        self._flush_interval = flush_interval
        self._now = now
        self._stop = threading.Event()
        self._wait_fn = wait if wait is not None else self._stop.wait
        self._lock = threading.Lock()  # guards every local file append / rename / delete
        self._flush_lock = threading.Lock()  # one spool flush at a time
        self._first_check = threading.Event()  # set after the background thread's first round

        target = self._spool_loop if mode == "realtime" else self._batch_loop
        self._thread = threading.Thread(target=target, name=f"ai-seeds-{mode}", daemon=True)
        self._thread.start()

    # ------------------------------------------------------------------ public

    def log(self, input: Any = _MISSING, cot: Any = _MISSING, output: Any = _MISSING,
            orders: Any = _MISSING) -> None:
        """Record one decision round.

        ``input`` / ``cot`` / ``output`` may be strings, JSON-like values, or model /
        framework objects (converted to JSON). ``orders`` is the list of orders
        finally executed this round (``[]`` when only holding).

        Raises:
            ValidationError: the log breaks a protocol rule; nothing is sent or written.
            UploadError: realtime only; the server refused it (400 / 401 / other 4xx).
        """
        timestamp = int(self._now() * 1000)
        event, text = self._build(timestamp, input, cot, output, orders)
        event_id = f"evt-{timestamp}-{uuid.uuid4().hex[:12]}"
        # Build the line from `text` so the stored event is byte-identical to what is hashed.
        line = '{"eventId":' + json.dumps(event_id) + ',"event":' + text + "}"
        if self.mode == "batch":
            day = _utc_date(timestamp / 1000.0).isoformat()
            self._append(os.path.join(self.batch_dir, day + ".jsonl"), line)
            return
        try:
            self._send_event(event_id, text)
        except UploadError as exc:
            if not exc.retryable:
                raise
            self._append(self.spool_path, line)
            logger.warning("ai-seeds: log %s not uploaded (%s); saved to %s, will retry automatically",
                           event_id, exc, self.spool_path)

    def close(self, timeout: float = 10.0) -> None:
        """Stop the background thread (optional; it never blocks interpreter exit)."""
        self._stop.set()
        if self._thread.is_alive() and self._thread is not threading.current_thread():
            self._thread.join(timeout)

    # ---------------------------------------------------------- build / send

    def _build(self, timestamp: int, input: Any, cot: Any, output: Any,
               orders: Any) -> Tuple[Dict[str, Any], str]:
        errors: List[str] = []
        data: Dict[str, Any] = {}
        for name, value, placeholder in (("input", input, "-"), ("cot", cot, "-"),
                                         ("output", output, "-"), ("orders", orders, [])):
            if value is _MISSING:
                value = None  # reported by validate_event as "is required"
            try:
                data[name] = validation.to_json_value(value, f"data.{name}")
            except ValueError as exc:
                errors.append(str(exc))
                data[name] = placeholder  # avoid a second message for the same field
        event = {"timestamp": timestamp, "data": data}
        errors.extend(validation.validate_event(event))
        if errors:
            raise ValidationError(errors)
        try:
            text = wire.compact_json(event)
            size = len(text.encode("utf-8"))
        except (TypeError, ValueError, UnicodeEncodeError) as exc:
            raise ValidationError([f"log is not valid JSON / UTF-8: {exc}"]) from None
        chunks = -(-size // wire.MAX_CHUNK_BYTES)
        if chunks > wire.MAX_CHUNK_COUNT:
            raise ValidationError([
                f"log is too large: {size} bytes needs about {chunks} chunks of 64 KB, "
                f"limit is {wire.MAX_CHUNK_COUNT}"
            ])
        if len(wire.split_chunks(text)) > wire.MAX_CHUNK_COUNT:
            raise ValidationError([f"log is too large: more than {wire.MAX_CHUNK_COUNT} chunks"])
        return event, text

    def _send_event(self, event_id: str, text: str) -> None:
        chunks = wire.split_chunks(text)
        envelope = {
            "protocolVersion": wire.PROTOCOL_VERSION,
            "address": self.address,
            "chunkCount": len(chunks),
            "totalBytes": len(text.encode("utf-8")),
            "contentSha256": wire.sha256_hex(text),
            "encoding": "plain",
        }
        for index, chunk in enumerate(chunks):
            body = wire.compact_json(dict(envelope, payload=chunk)).encode("utf-8")
            self._request("PUT", f"/v1/events/{event_id}/chunks/{index}", body, "application/json",
                          self._timeout, signed_content=body)

    # ------------------------------------------------------------ local files

    def _append(self, path: str, line: str) -> None:
        data = (line + "\n").encode("utf-8")
        with self._lock:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "ab") as fh:
                fh.write(data)

    @staticmethod
    def _append_bytes_locked(path: str, data: bytes) -> None:
        """Append raw bytes; the caller holds ``self._lock``."""
        if not data:
            return
        if not data.endswith(b"\n"):
            data += b"\n"
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "ab") as fh:
            fh.write(data)

    # ------------------------------------------------------- realtime: spool

    def _spool_loop(self) -> None:
        while not self._stop.is_set():
            try:
                self._flush_spool()
            except Exception:  # never let the background thread die
                logger.exception("ai-seeds: unexpected error while re-sending the spool")
            self._first_check.set()
            if self._wait_fn(self._flush_interval) or self._stop.is_set():
                return

    def _flush_spool(self) -> bool:
        """Upload the whole spool once. Returns True if nothing is left pending."""
        uploading = self.spool_path + ".uploading"
        with self._flush_lock:
            with self._lock:
                if os.path.exists(self.spool_path):
                    if os.path.exists(uploading):  # leftover of an interrupted flush: merge
                        with open(self.spool_path, "rb") as fh:
                            self._append_bytes_locked(uploading, fh.read())
                        os.remove(self.spool_path)
                    else:
                        os.replace(self.spool_path, uploading)
                if not os.path.exists(uploading):
                    return True
                with open(uploading, "rb") as fh:
                    content = fh.read()
            parts = wire.split_parts(wire.dedupe_lines(content), wire.MAX_FILE_BYTES, wire.MAX_FILE_LINES)
            done, error = self._upload_parts(parts, os.path.basename(self.spool_path))
            with self._lock:
                if error is not None:
                    # New logs may have been spooled meanwhile; put the unsent ones back next to them.
                    self._append_bytes_locked(self.spool_path, b"".join(parts[done:]))
                os.remove(uploading)
            if error is not None:
                logger.warning("ai-seeds: re-sending %d saved log(s) failed (%s); retrying in %gs",
                               sum(p.count(b"\n") for p in parts[done:]), error, self._flush_interval)
                return False
            if parts:
                logger.info("ai-seeds: re-sent %d saved log(s)", sum(p.count(b"\n") for p in parts))
            return True

    # ---------------------------------------------------------- batch: daily

    def _batch_loop(self) -> None:
        day = _utc_date(self._now())  # logs of `day` are pushed after the next UTC midnight
        while not self._stop.is_set():
            midnight = _midnight_after(day)
            push_at = midnight + random.uniform(*BATCH_DELAY_RANGE)  # new random delay every day
            if self._wait_until(push_at):
                return
            try:
                self._push_day(day, deadline=midnight + _DAY)
            except Exception:  # never let the background thread die
                logger.exception("ai-seeds: unexpected error while pushing %s", day.isoformat())
            day += _dt.timedelta(days=1)

    def _wait_until(self, target: float) -> bool:
        """Wait until the clock reaches ``target``; return True if the client was closed."""
        while not self._stop.is_set():
            remaining = target - self._now()
            if remaining <= 0:
                return False
            if self._wait_fn(min(remaining, _WAIT_STEP)):
                return True
        return True

    def _push_day(self, day: _dt.date, deadline: float) -> None:
        """Push the file of ``day`` as parts; retry failed parts until ``deadline``, then give up."""
        parts = self._prepare_parts(day.isoformat())
        while parts:
            failed: List[str] = []
            error: Optional[BaseException] = None
            for path in parts:
                try:
                    self._upload_file(path)
                except (UploadError, OSError) as exc:
                    failed.append(path)
                    error = exc
                    continue
                with self._lock:
                    os.remove(path)
            if not failed:
                logger.info("ai-seeds: pushed logs of %s (%d part file(s))", day.isoformat(), len(parts))
                return
            parts = failed
            retry_at = self._now() + BATCH_RETRY_INTERVAL
            if retry_at >= deadline:
                # manual_push.sh defaults to DEFAULT_BASE_URL; name the URL only when it differs.
                url = f"AI_SEEDS_URL={self.base_url} " if self.base_url != DEFAULT_BASE_URL else ""
                commands = (f"  {url}AI_SEEDS_ADDRESS={self.address} "
                            f"AI_SEEDS_SECRET=<your secret> sh {MANUAL_PUSH_SCRIPT} "
                            + " ".join(parts))
                logger.warning(
                    "ai-seeds: could not push %d part file(s) of %s (%s); automatic retry stopped. "
                    "The files are kept, push them manually:\n%s", len(parts), day.isoformat(), error, commands)
                return
            logger.warning("ai-seeds: pushing %d part file(s) of %s failed (%s); retrying in 30 minutes",
                           len(parts), day.isoformat(), error)
            if self._wait_until(retry_at):
                return

    def _prepare_parts(self, day: str) -> List[str]:
        """Split ``<day>.jsonl`` into deduplicated part files (<= 10 MB, <= 100000 lines each)."""
        source = os.path.join(self.batch_dir, day + ".jsonl")
        with self._lock:
            existing = self._part_files(day)
            if os.path.exists(source):
                with open(source, "rb") as fh:
                    lines = wire.dedupe_lines(fh.read())
                start = max((n for n, _ in existing), default=0) + 1
                bodies = wire.split_parts(lines, wire.MAX_FILE_BYTES, wire.MAX_FILE_LINES)
                for number, body in enumerate(bodies, start):
                    path = os.path.join(self.batch_dir, f"{day}.part{number}.jsonl")
                    with open(path + ".tmp", "wb") as fh:
                        fh.write(body)
                    os.replace(path + ".tmp", path)
                os.remove(source)
                existing = self._part_files(day)
            return [path for _, path in existing]

    def _part_files(self, day: str) -> List[Tuple[int, str]]:
        found = []
        for path in glob.glob(os.path.join(glob.escape(self.batch_dir), glob.escape(day) + ".part*.jsonl")):
            match = _PART_PATTERN.search(path)
            if match:
                found.append((int(match.group(1)), path))
        return sorted(found)

    # ------------------------------------------------------ internal upload

    def _upload_file(self, path: str) -> None:
        """Upload a JSONL file (deduplicated, split into parts within the server limits)."""
        with open(path, "rb") as fh:
            content = fh.read()
        parts = wire.split_parts(wire.dedupe_lines(content), wire.MAX_FILE_BYTES, wire.MAX_FILE_LINES)
        _, error = self._upload_parts(parts, os.path.basename(path))
        if error is not None:
            raise error

    def _upload_parts(self, parts: List[bytes], filename: str) -> Tuple[int, Optional[UploadError]]:
        """POST parts in order; return (number uploaded, error that stopped it or None)."""
        for index, body in enumerate(parts):
            name = filename
            if len(parts) > 1:
                stem, ext = os.path.splitext(filename)
                name = f"{stem}.part{index + 1}{ext}"
            multipart, content_type = wire.encode_multipart(
                [("address", self.address)], "file", name, body, "application/x-ndjson")
            try:
                # The signature covers the file part itself, not the multipart framing.
                self._request("POST", "/v1/files", multipart, content_type, FILE_TIMEOUT, signed_content=body)
            except UploadError as exc:
                return index, exc
        return len(parts), None

    # ------------------------------------------------------------------ HTTP

    def _request(self, method: str, path: str, body: bytes, content_type: str,
                 timeout: float, signed_content: bytes) -> Dict[str, Any]:
        """Send one request with the retry policy; return the parsed JSON body.

        Every attempt is signed afresh (new timestamp and nonce), see PROTOCOL.md section 2;
        ``signed_content`` is the request body for chunks and the file part for file uploads.
        """
        url = self.base_url + path
        content_sha256 = hashlib.sha256(signed_content).hexdigest()
        attempt = 0
        while True:
            nonce = uuid.uuid4().hex
            timestamp = str(int(self._now() * 1000))
            signature = wire.sign(self._secret, wire.canonical_string(
                method, path, timestamp, nonce, self.address, content_sha256))
            headers = {
                "Content-Type": content_type,
                "Accept": "application/json",
                "User-Agent": USER_AGENT,
                "X-AI-Seeds-Nonce": nonce,
                "X-AI-Seeds-Timestamp": timestamp,
                "X-AI-Seeds-Signature": signature,
            }
            request = urllib.request.Request(url, data=body, headers=headers, method=method)
            try:
                with urllib.request.urlopen(request, timeout=timeout) as response:
                    return _parse_json_object(response.read())
            except urllib.error.HTTPError as exc:
                error = _error_from_response(exc)
                if not error.retryable:
                    raise error from None
            except (OSError, http.client.HTTPException) as exc:
                error = UploadError(None, "NETWORK_ERROR", str(exc) or type(exc).__name__,
                                    retryable=True)
            if attempt >= self._retries:
                raise error
            delay = self._backoff * (2 ** attempt)
            logger.info("ai-seeds: %s %s failed (%s); retry %d/%d in %.1fs",
                        method, path, error, attempt + 1, self._retries, delay)
            self._sleep(delay)
            attempt += 1


def _utc_date(epoch_seconds: float) -> _dt.date:
    return _dt.datetime.fromtimestamp(epoch_seconds, _dt.timezone.utc).date()


def _midnight_after(day: _dt.date) -> float:
    """Epoch seconds of the UTC midnight that ends ``day``."""
    nxt = day + _dt.timedelta(days=1)
    return _dt.datetime(nxt.year, nxt.month, nxt.day, tzinfo=_dt.timezone.utc).timestamp()


def _parse_json_object(raw: bytes) -> Dict[str, Any]:
    try:
        value = json.loads(raw.decode("utf-8")) if raw else {}
    except ValueError:
        return {}
    return value if isinstance(value, dict) else {}


def _error_from_response(exc: urllib.error.HTTPError) -> UploadError:
    status = exc.code
    try:
        raw = exc.read()
    except Exception:  # body unreadable; keep going with status only
        raw = b""
    finally:
        exc.close()
    body = _parse_json_object(raw)
    code = str(body.get("code") or f"HTTP_{status}")
    message = str(body.get("error") or body.get("message") or exc.reason or "")
    line_errors = body.get("lineErrors")
    if not isinstance(line_errors, list):
        line_errors = []
    if line_errors:
        details = "; ".join(
            f"line {item.get('line')}: {item.get('error')}" if isinstance(item, dict) else str(item)
            for item in line_errors
        )
        message = f"{message}: {details}" if message else details
    retryable = status >= 500 or status == 429
    return UploadError(status, code, message, line_errors, retryable)
